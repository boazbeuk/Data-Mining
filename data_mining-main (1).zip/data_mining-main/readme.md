
### Data mining
- Task 1 : Data Prep
- Task 2 : Classification
- Task 3 : Association rules
- Task 4 : Numerical prediction
- Task 5 : Evaluation
